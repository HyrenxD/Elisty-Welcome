# 🔊 null welcome
######  Herkese selam
######  yeni versiyon sizlerle.
######  0.0.3

# 🌟 Yenilikler
###### Değişen oynuyor
###### Ses logu hataları giderildi.
###### Main ve json dosyalarında değişiklerler.

# 🎀 Açıklama
###### Jaylen ozi mi ney ismi amına koyayım her güncellemede bakıp bakıp geçiriyor amına koyayım adamlar gelip ozi bot diyor :D
###### siktir git kendi botuna kendi sesini koy ayrıca benden alıp koyuyorsun 
###### Bot işlerinden sıkıldım son güncelleme bu olucaktır.


<h2 align="center">Discord Hesaplarım <img src="https://raw.githubusercontent.com/iampavangandhi/iampavangandhi/master/gifs/Hi.gif" width="30px"> </h2>

[![Discord Presence](https://lanyard-profile-readme.vercel.app/api/769979665224958020?hideDiscrim=true)](https://discord.com/users/769979665224958020)
